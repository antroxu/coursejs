IMPORTANT: please note that the autoFormat feature (format-as-you-type) was removed in v8.0.0 - read more here: https://github.com/jackocnr/intl-tel-input/issues/346. Please do not open any new issues about this topic.

IMPORTANT: we use libphonenumber for formatting and validation - if your issue relates to one of these things, please check their test site first and if you see the problem there please file an issue with them instead: https://rawgit.com/googlei18n/libphonenumber/master/javascript/i18n/phonenumbers/demo-compiled.html

### Steps to reproduce
1.  
2.  
3.  

### Expected behaviour
Tell us what should happen

### Actual behaviour
Tell us what actually happens

### Initialisation options
List any options you're using e.g. utilsScript or preferredCountries
